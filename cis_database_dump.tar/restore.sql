--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.12
-- Dumped by pg_dump version 9.5.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_5efe36e69614ded2_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT djang_content_type_id_b87e6cf28123f49_fk_django_content_type_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permiss_user_id_23ee5668564f25c7_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_4a70ae77c7552797_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_39d938ca429ae2b6_fk_auth_group_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user__permission_id_5c7814e2d3edea43_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permission_id_7f1d7f7f558c03f0_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_group_id_181e738b12afa77f_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_content_type_id_28a8768a279c8196_fk_django_content_type_id;
ALTER TABLE ONLY public."PeopleNotes" DROP CONSTRAINT "PeopleNotes_PeopleId_id_5e454f14778567e5_fk_People_Id";
ALTER TABLE ONLY public."Groups" DROP CONSTRAINT "Groups_GroupTypeId_id_660c2068939cb343_fk_GroupTypes_Id";
ALTER TABLE ONLY public."Groups" DROP CONSTRAINT "Groups_DepartmentId_id_1fd2221bcc7c6999_fk_Departments_Id";
ALTER TABLE ONLY public."GroupNotes" DROP CONSTRAINT "GroupNotes_GroupId_id_4f13094c9c6c9b09_fk_Groups_Id";
ALTER TABLE ONLY public."GroupMembers" DROP CONSTRAINT "GroupMembers_PeopleId_id_285f3db711a914dd_fk_People_Id";
ALTER TABLE ONLY public."GroupMembers" DROP CONSTRAINT "GroupMembers_GroupRoleId_id_2cd64b205c46a425_fk_GroupRoles_Id";
ALTER TABLE ONLY public."GroupMembers" DROP CONSTRAINT "GroupMembers_GroupId_id_5aebab87513160d4_fk_Groups_Id";
ALTER TABLE ONLY public."GroupMembers" DROP CONSTRAINT "GroupMembers_GradeId_id_280ab09187a49ecf_fk_Grades_Id";
ALTER TABLE ONLY public."FamilyNotes" DROP CONSTRAINT "FamilyNotes_FamilyId_id_4406aef21b337277_fk_Families_Id";
ALTER TABLE ONLY public."FamilyMembers" DROP CONSTRAINT "FamilyMembers_PeopleId_id_72d4c547cf9be6c7_fk_People_Id";
ALTER TABLE ONLY public."FamilyMembers" DROP CONSTRAINT "FamilyMembers_FamilyId_id_129f4f7cb4f56da0_fk_Families_Id";
ALTER TABLE ONLY public."FamilyMembers" DROP CONSTRAINT "FamilyMember_FamilyRoleId_id_1d57647d974330c3_fk_FamilyRoles_Id";
ALTER TABLE ONLY public."ContactEntries" DROP CONSTRAINT "ContactEntries_PeopleId_id_1af2037cccdb6273_fk_People_Id";
ALTER TABLE ONLY public."ContactEntries" DROP CONSTRAINT "ContactEnt_ContactTypeId_id_69523d2b4b5c67c2_fk_ContactTypes_Id";
DROP INDEX public.django_session_session_key_673d0e97290e0b46_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.auth_user_username_3baa172c8eecbcda_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_4e580194b55c6de3_like;
DROP INDEX public."PeopleNotes_b7ab1fa0";
DROP INDEX public."Groups_df9cb402";
DROP INDEX public."Groups_9997bc12";
DROP INDEX public."GroupNotes_b426c878";
DROP INDEX public."GroupMembers_d214f22a";
DROP INDEX public."GroupMembers_b7ab1fa0";
DROP INDEX public."GroupMembers_b426c878";
DROP INDEX public."GroupMembers_9f1ff75d";
DROP INDEX public."FamilyNotes_66c44a64";
DROP INDEX public."FamilyMembers_b7ab1fa0";
DROP INDEX public."FamilyMembers_9a60a2fa";
DROP INDEX public."FamilyMembers_66c44a64";
DROP INDEX public."ContactEntries_b7ab1fa0";
DROP INDEX public."ContactEntries_1242c665";
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_69cbe8f8860e3c4b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_key;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE ONLY public."People" DROP CONSTRAINT "People_pkey";
ALTER TABLE ONLY public."PeopleNotes" DROP CONSTRAINT "PeopleNotes_pkey";
ALTER TABLE ONLY public."Groups" DROP CONSTRAINT "Groups_pkey";
ALTER TABLE ONLY public."GroupTypes" DROP CONSTRAINT "GroupTypes_pkey";
ALTER TABLE ONLY public."GroupRoles" DROP CONSTRAINT "GroupRoles_pkey";
ALTER TABLE ONLY public."GroupNotes" DROP CONSTRAINT "GroupNotes_pkey";
ALTER TABLE ONLY public."GroupMembers" DROP CONSTRAINT "GroupMembers_pkey";
ALTER TABLE ONLY public."Grades" DROP CONSTRAINT "Grades_pkey";
ALTER TABLE ONLY public."FamilyRoles" DROP CONSTRAINT "FamilyRoles_pkey";
ALTER TABLE ONLY public."FamilyNotes" DROP CONSTRAINT "FamilyNotes_pkey";
ALTER TABLE ONLY public."FamilyMembers" DROP CONSTRAINT "FamilyMembers_pkey";
ALTER TABLE ONLY public."Families" DROP CONSTRAINT "Families_pkey";
ALTER TABLE ONLY public."Departments" DROP CONSTRAINT "Departments_pkey";
ALTER TABLE ONLY public."ContactTypes" DROP CONSTRAINT "ContactTypes_pkey";
ALTER TABLE ONLY public."ContactEntries" DROP CONSTRAINT "ContactEntries_pkey";
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."PeopleNotes" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."People" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Groups" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."GroupTypes" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."GroupRoles" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."GroupNotes" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."GroupMembers" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Grades" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."FamilyRoles" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."FamilyNotes" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."FamilyMembers" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Families" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."Departments" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."ContactTypes" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."ContactEntries" ALTER COLUMN "Id" DROP DEFAULT;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP SEQUENCE public."People_Id_seq";
DROP SEQUENCE public."PeopleNotes_Id_seq";
DROP TABLE public."PeopleNotes";
DROP TABLE public."People";
DROP SEQUENCE public."Groups_Id_seq";
DROP TABLE public."Groups";
DROP SEQUENCE public."GroupTypes_Id_seq";
DROP TABLE public."GroupTypes";
DROP SEQUENCE public."GroupRoles_Id_seq";
DROP TABLE public."GroupRoles";
DROP SEQUENCE public."GroupNotes_Id_seq";
DROP TABLE public."GroupNotes";
DROP SEQUENCE public."GroupMembers_Id_seq";
DROP TABLE public."GroupMembers";
DROP SEQUENCE public."Grades_Id_seq";
DROP TABLE public."Grades";
DROP SEQUENCE public."FamilyRoles_Id_seq";
DROP TABLE public."FamilyRoles";
DROP SEQUENCE public."FamilyNotes_Id_seq";
DROP TABLE public."FamilyNotes";
DROP SEQUENCE public."FamilyMembers_Id_seq";
DROP TABLE public."FamilyMembers";
DROP SEQUENCE public."Families_Id_seq";
DROP TABLE public."Families";
DROP SEQUENCE public."Departments_Id_seq";
DROP TABLE public."Departments";
DROP SEQUENCE public."ContactTypes_Id_seq";
DROP TABLE public."ContactTypes";
DROP SEQUENCE public."ContactEntries_Id_seq";
DROP TABLE public."ContactEntries";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ContactEntries; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."ContactEntries" (
    "Id" integer NOT NULL,
    "PeopleId_id" integer NOT NULL,
    "ContactTypeId_id" integer NOT NULL,
    "Address" character varying(254),
    "City" character varying(100),
    "State" character varying(2),
    "Zip" character varying(10),
    "Phone" character varying(25),
    "Email" character varying(254)
);


ALTER TABLE public."ContactEntries" OWNER TO cisadmin;

--
-- Name: ContactEntries_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."ContactEntries_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactEntries_Id_seq" OWNER TO cisadmin;

--
-- Name: ContactEntries_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."ContactEntries_Id_seq" OWNED BY public."ContactEntries"."Id";


--
-- Name: ContactTypes; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."ContactTypes" (
    "Id" integer NOT NULL,
    "Type" character varying(30) NOT NULL,
    "Description" character varying(254)
);


ALTER TABLE public."ContactTypes" OWNER TO cisadmin;

--
-- Name: ContactTypes_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."ContactTypes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactTypes_Id_seq" OWNER TO cisadmin;

--
-- Name: ContactTypes_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."ContactTypes_Id_seq" OWNED BY public."ContactTypes"."Id";


--
-- Name: Departments; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."Departments" (
    "Id" integer NOT NULL,
    "Name" character varying(40) NOT NULL,
    "Description" character varying(254)
);


ALTER TABLE public."Departments" OWNER TO cisadmin;

--
-- Name: Departments_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."Departments_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Departments_Id_seq" OWNER TO cisadmin;

--
-- Name: Departments_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."Departments_Id_seq" OWNED BY public."Departments"."Id";


--
-- Name: Families; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."Families" (
    "Id" integer NOT NULL,
    "Surname" character varying(40) NOT NULL,
    "Description" character varying(254),
    "Address" character varying(254),
    "City" character varying(100),
    "State" character varying(2),
    "Zip" character varying(10)
);


ALTER TABLE public."Families" OWNER TO cisadmin;

--
-- Name: Families_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."Families_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Families_Id_seq" OWNER TO cisadmin;

--
-- Name: Families_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."Families_Id_seq" OWNED BY public."Families"."Id";


--
-- Name: FamilyMembers; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."FamilyMembers" (
    "Id" integer NOT NULL,
    "FamilyId_id" integer NOT NULL,
    "FamilyRoleId_id" integer NOT NULL,
    "PeopleId_id" integer NOT NULL
);


ALTER TABLE public."FamilyMembers" OWNER TO cisadmin;

--
-- Name: FamilyMembers_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."FamilyMembers_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FamilyMembers_Id_seq" OWNER TO cisadmin;

--
-- Name: FamilyMembers_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."FamilyMembers_Id_seq" OWNED BY public."FamilyMembers"."Id";


--
-- Name: FamilyNotes; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."FamilyNotes" (
    "Id" integer NOT NULL,
    "Note" text,
    "FamilyId_id" integer NOT NULL
);


ALTER TABLE public."FamilyNotes" OWNER TO cisadmin;

--
-- Name: FamilyNotes_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."FamilyNotes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FamilyNotes_Id_seq" OWNER TO cisadmin;

--
-- Name: FamilyNotes_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."FamilyNotes_Id_seq" OWNED BY public."FamilyNotes"."Id";


--
-- Name: FamilyRoles; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."FamilyRoles" (
    "Id" integer NOT NULL,
    "Role" character varying(40) NOT NULL,
    "Description" character varying(254)
);


ALTER TABLE public."FamilyRoles" OWNER TO cisadmin;

--
-- Name: FamilyRoles_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."FamilyRoles_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FamilyRoles_Id_seq" OWNER TO cisadmin;

--
-- Name: FamilyRoles_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."FamilyRoles_Id_seq" OWNED BY public."FamilyRoles"."Id";


--
-- Name: Grades; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."Grades" (
    "Id" integer NOT NULL,
    "Grade" character varying(12) NOT NULL
);


ALTER TABLE public."Grades" OWNER TO cisadmin;

--
-- Name: Grades_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."Grades_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Grades_Id_seq" OWNER TO cisadmin;

--
-- Name: Grades_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."Grades_Id_seq" OWNED BY public."Grades"."Id";


--
-- Name: GroupMembers; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."GroupMembers" (
    "Id" integer NOT NULL,
    "PeopleId_id" integer NOT NULL,
    "GroupId_id" integer NOT NULL,
    "GroupRoleId_id" integer NOT NULL,
    "GradeId_id" integer NOT NULL
);


ALTER TABLE public."GroupMembers" OWNER TO cisadmin;

--
-- Name: GroupMembers_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."GroupMembers_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GroupMembers_Id_seq" OWNER TO cisadmin;

--
-- Name: GroupMembers_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."GroupMembers_Id_seq" OWNED BY public."GroupMembers"."Id";


--
-- Name: GroupNotes; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."GroupNotes" (
    "Id" integer NOT NULL,
    "Note" text,
    "GroupId_id" integer NOT NULL
);


ALTER TABLE public."GroupNotes" OWNER TO cisadmin;

--
-- Name: GroupNotes_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."GroupNotes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GroupNotes_Id_seq" OWNER TO cisadmin;

--
-- Name: GroupNotes_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."GroupNotes_Id_seq" OWNED BY public."GroupNotes"."Id";


--
-- Name: GroupRoles; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."GroupRoles" (
    "Id" integer NOT NULL,
    "Role" character varying(40) NOT NULL,
    "Description" character varying(254)
);


ALTER TABLE public."GroupRoles" OWNER TO cisadmin;

--
-- Name: GroupRoles_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."GroupRoles_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GroupRoles_Id_seq" OWNER TO cisadmin;

--
-- Name: GroupRoles_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."GroupRoles_Id_seq" OWNED BY public."GroupRoles"."Id";


--
-- Name: GroupTypes; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."GroupTypes" (
    "Id" integer NOT NULL,
    "Type" character varying(40) NOT NULL,
    "Description" character varying(254)
);


ALTER TABLE public."GroupTypes" OWNER TO cisadmin;

--
-- Name: GroupTypes_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."GroupTypes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GroupTypes_Id_seq" OWNER TO cisadmin;

--
-- Name: GroupTypes_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."GroupTypes_Id_seq" OWNED BY public."GroupTypes"."Id";


--
-- Name: Groups; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."Groups" (
    "Id" integer NOT NULL,
    "Name" character varying(40) NOT NULL,
    "Description" character varying(254),
    "DepartmentId_id" integer NOT NULL,
    "GroupTypeId_id" integer NOT NULL
);


ALTER TABLE public."Groups" OWNER TO cisadmin;

--
-- Name: Groups_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."Groups_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Groups_Id_seq" OWNER TO cisadmin;

--
-- Name: Groups_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."Groups_Id_seq" OWNED BY public."Groups"."Id";


--
-- Name: People; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."People" (
    "Id" integer NOT NULL,
    "LastName" character varying(40) NOT NULL,
    "FirstName" character varying(40) NOT NULL,
    "MiddleName" character varying(40),
    "Birthday" date,
    "Anniversary" date
);


ALTER TABLE public."People" OWNER TO cisadmin;

--
-- Name: PeopleNotes; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public."PeopleNotes" (
    "Id" integer NOT NULL,
    "Note" text,
    "PeopleId_id" integer NOT NULL
);


ALTER TABLE public."PeopleNotes" OWNER TO cisadmin;

--
-- Name: PeopleNotes_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."PeopleNotes_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PeopleNotes_Id_seq" OWNER TO cisadmin;

--
-- Name: PeopleNotes_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."PeopleNotes_Id_seq" OWNED BY public."PeopleNotes"."Id";


--
-- Name: People_Id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public."People_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."People_Id_seq" OWNER TO cisadmin;

--
-- Name: People_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public."People_Id_seq" OWNED BY public."People"."Id";


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO cisadmin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO cisadmin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO cisadmin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO cisadmin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO cisadmin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO cisadmin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO cisadmin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO cisadmin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO cisadmin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO cisadmin;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO cisadmin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO cisadmin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO cisadmin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO cisadmin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO cisadmin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO cisadmin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO cisadmin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: cisadmin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO cisadmin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cisadmin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: cisadmin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO cisadmin;

--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."ContactEntries" ALTER COLUMN "Id" SET DEFAULT nextval('public."ContactEntries_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."ContactTypes" ALTER COLUMN "Id" SET DEFAULT nextval('public."ContactTypes_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Departments" ALTER COLUMN "Id" SET DEFAULT nextval('public."Departments_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Families" ALTER COLUMN "Id" SET DEFAULT nextval('public."Families_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyMembers" ALTER COLUMN "Id" SET DEFAULT nextval('public."FamilyMembers_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyNotes" ALTER COLUMN "Id" SET DEFAULT nextval('public."FamilyNotes_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyRoles" ALTER COLUMN "Id" SET DEFAULT nextval('public."FamilyRoles_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Grades" ALTER COLUMN "Id" SET DEFAULT nextval('public."Grades_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupMembers" ALTER COLUMN "Id" SET DEFAULT nextval('public."GroupMembers_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupNotes" ALTER COLUMN "Id" SET DEFAULT nextval('public."GroupNotes_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupRoles" ALTER COLUMN "Id" SET DEFAULT nextval('public."GroupRoles_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupTypes" ALTER COLUMN "Id" SET DEFAULT nextval('public."GroupTypes_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Groups" ALTER COLUMN "Id" SET DEFAULT nextval('public."Groups_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."People" ALTER COLUMN "Id" SET DEFAULT nextval('public."People_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."PeopleNotes" ALTER COLUMN "Id" SET DEFAULT nextval('public."PeopleNotes_Id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: ContactEntries; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."ContactEntries" ("Id", "PeopleId_id", "ContactTypeId_id", "Address", "City", "State", "Zip", "Phone", "Email") FROM stdin;
\.
COPY public."ContactEntries" ("Id", "PeopleId_id", "ContactTypeId_id", "Address", "City", "State", "Zip", "Phone", "Email") FROM '$$PATH$$/2389.dat';

--
-- Name: ContactEntries_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."ContactEntries_Id_seq"', 3611, true);


--
-- Data for Name: ContactTypes; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."ContactTypes" ("Id", "Type", "Description") FROM stdin;
\.
COPY public."ContactTypes" ("Id", "Type", "Description") FROM '$$PATH$$/2391.dat';

--
-- Name: ContactTypes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."ContactTypes_Id_seq"', 4, true);


--
-- Data for Name: Departments; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."Departments" ("Id", "Name", "Description") FROM stdin;
\.
COPY public."Departments" ("Id", "Name", "Description") FROM '$$PATH$$/2393.dat';

--
-- Name: Departments_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."Departments_Id_seq"', 4, true);


--
-- Data for Name: Families; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."Families" ("Id", "Surname", "Description", "Address", "City", "State", "Zip") FROM stdin;
\.
COPY public."Families" ("Id", "Surname", "Description", "Address", "City", "State", "Zip") FROM '$$PATH$$/2395.dat';

--
-- Name: Families_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."Families_Id_seq"', 3, true);


--
-- Data for Name: FamilyMembers; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."FamilyMembers" ("Id", "FamilyId_id", "FamilyRoleId_id", "PeopleId_id") FROM stdin;
\.
COPY public."FamilyMembers" ("Id", "FamilyId_id", "FamilyRoleId_id", "PeopleId_id") FROM '$$PATH$$/2397.dat';

--
-- Name: FamilyMembers_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."FamilyMembers_Id_seq"', 6, true);


--
-- Data for Name: FamilyNotes; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."FamilyNotes" ("Id", "Note", "FamilyId_id") FROM stdin;
\.
COPY public."FamilyNotes" ("Id", "Note", "FamilyId_id") FROM '$$PATH$$/2399.dat';

--
-- Name: FamilyNotes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."FamilyNotes_Id_seq"', 1, false);


--
-- Data for Name: FamilyRoles; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."FamilyRoles" ("Id", "Role", "Description") FROM stdin;
\.
COPY public."FamilyRoles" ("Id", "Role", "Description") FROM '$$PATH$$/2401.dat';

--
-- Name: FamilyRoles_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."FamilyRoles_Id_seq"', 6, true);


--
-- Data for Name: Grades; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."Grades" ("Id", "Grade") FROM stdin;
\.
COPY public."Grades" ("Id", "Grade") FROM '$$PATH$$/2403.dat';

--
-- Name: Grades_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."Grades_Id_seq"', 15, true);


--
-- Data for Name: GroupMembers; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."GroupMembers" ("Id", "PeopleId_id", "GroupId_id", "GroupRoleId_id", "GradeId_id") FROM stdin;
\.
COPY public."GroupMembers" ("Id", "PeopleId_id", "GroupId_id", "GroupRoleId_id", "GradeId_id") FROM '$$PATH$$/2405.dat';

--
-- Name: GroupMembers_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."GroupMembers_Id_seq"', 2619, true);


--
-- Data for Name: GroupNotes; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."GroupNotes" ("Id", "Note", "GroupId_id") FROM stdin;
\.
COPY public."GroupNotes" ("Id", "Note", "GroupId_id") FROM '$$PATH$$/2407.dat';

--
-- Name: GroupNotes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."GroupNotes_Id_seq"', 1, false);


--
-- Data for Name: GroupRoles; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."GroupRoles" ("Id", "Role", "Description") FROM stdin;
\.
COPY public."GroupRoles" ("Id", "Role", "Description") FROM '$$PATH$$/2409.dat';

--
-- Name: GroupRoles_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."GroupRoles_Id_seq"', 21, true);


--
-- Data for Name: GroupTypes; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."GroupTypes" ("Id", "Type", "Description") FROM stdin;
\.
COPY public."GroupTypes" ("Id", "Type", "Description") FROM '$$PATH$$/2411.dat';

--
-- Name: GroupTypes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."GroupTypes_Id_seq"', 2, true);


--
-- Data for Name: Groups; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."Groups" ("Id", "Name", "Description", "DepartmentId_id", "GroupTypeId_id") FROM stdin;
\.
COPY public."Groups" ("Id", "Name", "Description", "DepartmentId_id", "GroupTypeId_id") FROM '$$PATH$$/2413.dat';

--
-- Name: Groups_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."Groups_Id_seq"', 21, true);


--
-- Data for Name: People; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."People" ("Id", "LastName", "FirstName", "MiddleName", "Birthday", "Anniversary") FROM stdin;
\.
COPY public."People" ("Id", "LastName", "FirstName", "MiddleName", "Birthday", "Anniversary") FROM '$$PATH$$/2415.dat';

--
-- Data for Name: PeopleNotes; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public."PeopleNotes" ("Id", "Note", "PeopleId_id") FROM stdin;
\.
COPY public."PeopleNotes" ("Id", "Note", "PeopleId_id") FROM '$$PATH$$/2416.dat';

--
-- Name: PeopleNotes_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."PeopleNotes_Id_seq"', 1, false);


--
-- Name: People_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public."People_Id_seq"', 2615, true);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/2419.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2421.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2423.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 63, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2425.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2426.dat';

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2429.dat';

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2431.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 529, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/2433.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 21, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/2435.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cisadmin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 17, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: cisadmin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2437.dat';

--
-- Name: ContactEntries_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."ContactEntries"
    ADD CONSTRAINT "ContactEntries_pkey" PRIMARY KEY ("Id");


--
-- Name: ContactTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."ContactTypes"
    ADD CONSTRAINT "ContactTypes_pkey" PRIMARY KEY ("Id");


--
-- Name: Departments_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Departments"
    ADD CONSTRAINT "Departments_pkey" PRIMARY KEY ("Id");


--
-- Name: Families_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Families"
    ADD CONSTRAINT "Families_pkey" PRIMARY KEY ("Id");


--
-- Name: FamilyMembers_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyMembers"
    ADD CONSTRAINT "FamilyMembers_pkey" PRIMARY KEY ("Id");


--
-- Name: FamilyNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyNotes"
    ADD CONSTRAINT "FamilyNotes_pkey" PRIMARY KEY ("Id");


--
-- Name: FamilyRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyRoles"
    ADD CONSTRAINT "FamilyRoles_pkey" PRIMARY KEY ("Id");


--
-- Name: Grades_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Grades"
    ADD CONSTRAINT "Grades_pkey" PRIMARY KEY ("Id");


--
-- Name: GroupMembers_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupMembers"
    ADD CONSTRAINT "GroupMembers_pkey" PRIMARY KEY ("Id");


--
-- Name: GroupNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupNotes"
    ADD CONSTRAINT "GroupNotes_pkey" PRIMARY KEY ("Id");


--
-- Name: GroupRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupRoles"
    ADD CONSTRAINT "GroupRoles_pkey" PRIMARY KEY ("Id");


--
-- Name: GroupTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupTypes"
    ADD CONSTRAINT "GroupTypes_pkey" PRIMARY KEY ("Id");


--
-- Name: Groups_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Groups"
    ADD CONSTRAINT "Groups_pkey" PRIMARY KEY ("Id");


--
-- Name: PeopleNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."PeopleNotes"
    ADD CONSTRAINT "PeopleNotes_pkey" PRIMARY KEY ("Id");


--
-- Name: People_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_pkey" PRIMARY KEY ("Id");


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_69cbe8f8860e3c4b_uniq; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_69cbe8f8860e3c4b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: ContactEntries_1242c665; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "ContactEntries_1242c665" ON public."ContactEntries" USING btree ("ContactTypeId_id");


--
-- Name: ContactEntries_b7ab1fa0; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "ContactEntries_b7ab1fa0" ON public."ContactEntries" USING btree ("PeopleId_id");


--
-- Name: FamilyMembers_66c44a64; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "FamilyMembers_66c44a64" ON public."FamilyMembers" USING btree ("FamilyId_id");


--
-- Name: FamilyMembers_9a60a2fa; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "FamilyMembers_9a60a2fa" ON public."FamilyMembers" USING btree ("FamilyRoleId_id");


--
-- Name: FamilyMembers_b7ab1fa0; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "FamilyMembers_b7ab1fa0" ON public."FamilyMembers" USING btree ("PeopleId_id");


--
-- Name: FamilyNotes_66c44a64; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "FamilyNotes_66c44a64" ON public."FamilyNotes" USING btree ("FamilyId_id");


--
-- Name: GroupMembers_9f1ff75d; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "GroupMembers_9f1ff75d" ON public."GroupMembers" USING btree ("GroupRoleId_id");


--
-- Name: GroupMembers_b426c878; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "GroupMembers_b426c878" ON public."GroupMembers" USING btree ("GroupId_id");


--
-- Name: GroupMembers_b7ab1fa0; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "GroupMembers_b7ab1fa0" ON public."GroupMembers" USING btree ("PeopleId_id");


--
-- Name: GroupMembers_d214f22a; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "GroupMembers_d214f22a" ON public."GroupMembers" USING btree ("GradeId_id");


--
-- Name: GroupNotes_b426c878; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "GroupNotes_b426c878" ON public."GroupNotes" USING btree ("GroupId_id");


--
-- Name: Groups_9997bc12; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "Groups_9997bc12" ON public."Groups" USING btree ("GroupTypeId_id");


--
-- Name: Groups_df9cb402; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "Groups_df9cb402" ON public."Groups" USING btree ("DepartmentId_id");


--
-- Name: PeopleNotes_b7ab1fa0; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX "PeopleNotes_b7ab1fa0" ON public."PeopleNotes" USING btree ("PeopleId_id");


--
-- Name: auth_group_name_4e580194b55c6de3_like; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_group_name_4e580194b55c6de3_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_user_groups_0e939a4f ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_user_groups_e8701ad4 ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_user_user_permissions_8373b171 ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_3baa172c8eecbcda_like; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX auth_user_username_3baa172c8eecbcda_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_673d0e97290e0b46_like; Type: INDEX; Schema: public; Owner: cisadmin
--

CREATE INDEX django_session_session_key_673d0e97290e0b46_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: ContactEnt_ContactTypeId_id_69523d2b4b5c67c2_fk_ContactTypes_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."ContactEntries"
    ADD CONSTRAINT "ContactEnt_ContactTypeId_id_69523d2b4b5c67c2_fk_ContactTypes_Id" FOREIGN KEY ("ContactTypeId_id") REFERENCES public."ContactTypes"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ContactEntries_PeopleId_id_1af2037cccdb6273_fk_People_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."ContactEntries"
    ADD CONSTRAINT "ContactEntries_PeopleId_id_1af2037cccdb6273_fk_People_Id" FOREIGN KEY ("PeopleId_id") REFERENCES public."People"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: FamilyMember_FamilyRoleId_id_1d57647d974330c3_fk_FamilyRoles_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyMembers"
    ADD CONSTRAINT "FamilyMember_FamilyRoleId_id_1d57647d974330c3_fk_FamilyRoles_Id" FOREIGN KEY ("FamilyRoleId_id") REFERENCES public."FamilyRoles"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: FamilyMembers_FamilyId_id_129f4f7cb4f56da0_fk_Families_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyMembers"
    ADD CONSTRAINT "FamilyMembers_FamilyId_id_129f4f7cb4f56da0_fk_Families_Id" FOREIGN KEY ("FamilyId_id") REFERENCES public."Families"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: FamilyMembers_PeopleId_id_72d4c547cf9be6c7_fk_People_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyMembers"
    ADD CONSTRAINT "FamilyMembers_PeopleId_id_72d4c547cf9be6c7_fk_People_Id" FOREIGN KEY ("PeopleId_id") REFERENCES public."People"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: FamilyNotes_FamilyId_id_4406aef21b337277_fk_Families_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."FamilyNotes"
    ADD CONSTRAINT "FamilyNotes_FamilyId_id_4406aef21b337277_fk_Families_Id" FOREIGN KEY ("FamilyId_id") REFERENCES public."Families"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: GroupMembers_GradeId_id_280ab09187a49ecf_fk_Grades_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupMembers"
    ADD CONSTRAINT "GroupMembers_GradeId_id_280ab09187a49ecf_fk_Grades_Id" FOREIGN KEY ("GradeId_id") REFERENCES public."Grades"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: GroupMembers_GroupId_id_5aebab87513160d4_fk_Groups_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupMembers"
    ADD CONSTRAINT "GroupMembers_GroupId_id_5aebab87513160d4_fk_Groups_Id" FOREIGN KEY ("GroupId_id") REFERENCES public."Groups"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: GroupMembers_GroupRoleId_id_2cd64b205c46a425_fk_GroupRoles_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupMembers"
    ADD CONSTRAINT "GroupMembers_GroupRoleId_id_2cd64b205c46a425_fk_GroupRoles_Id" FOREIGN KEY ("GroupRoleId_id") REFERENCES public."GroupRoles"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: GroupMembers_PeopleId_id_285f3db711a914dd_fk_People_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupMembers"
    ADD CONSTRAINT "GroupMembers_PeopleId_id_285f3db711a914dd_fk_People_Id" FOREIGN KEY ("PeopleId_id") REFERENCES public."People"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: GroupNotes_GroupId_id_4f13094c9c6c9b09_fk_Groups_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."GroupNotes"
    ADD CONSTRAINT "GroupNotes_GroupId_id_4f13094c9c6c9b09_fk_Groups_Id" FOREIGN KEY ("GroupId_id") REFERENCES public."Groups"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: Groups_DepartmentId_id_1fd2221bcc7c6999_fk_Departments_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Groups"
    ADD CONSTRAINT "Groups_DepartmentId_id_1fd2221bcc7c6999_fk_Departments_Id" FOREIGN KEY ("DepartmentId_id") REFERENCES public."Departments"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: Groups_GroupTypeId_id_660c2068939cb343_fk_GroupTypes_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."Groups"
    ADD CONSTRAINT "Groups_GroupTypeId_id_660c2068939cb343_fk_GroupTypes_Id" FOREIGN KEY ("GroupTypeId_id") REFERENCES public."GroupTypes"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: PeopleNotes_PeopleId_id_5e454f14778567e5_fk_People_Id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public."PeopleNotes"
    ADD CONSTRAINT "PeopleNotes_PeopleId_id_5e454f14778567e5_fk_People_Id" FOREIGN KEY ("PeopleId_id") REFERENCES public."People"("Id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_content_type_id_28a8768a279c8196_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_content_type_id_28a8768a279c8196_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_181e738b12afa77f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_181e738b12afa77f_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_7f1d7f7f558c03f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_7f1d7f7f558c03f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_5c7814e2d3edea43_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_5c7814e2d3edea43_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_39d938ca429ae2b6_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_39d938ca429ae2b6_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4a70ae77c7552797_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4a70ae77c7552797_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_23ee5668564f25c7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_23ee5668564f25c7_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djang_content_type_id_b87e6cf28123f49_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT djang_content_type_id_b87e6cf28123f49_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_5efe36e69614ded2_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: cisadmin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_5efe36e69614ded2_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

